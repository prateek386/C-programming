import java.util.*;
class Laptop1 implements Comparable<Laptop>
{
	private int lid;
	private String make;
	private double cost;
	
	public int getLid()
	{
		return lid;
	}
	
	public Laptop1()
	{
	}
	
	public Laptop1(int lid, String make, double cost)
	{
		super();
		this.lid=lid;
		this.make=make;
		this.cost=cost;
	}
	
	public void display()
	{
		System.out.println(lid+" "+make+" "+cost);
	}
	
	public int hashCode()
	{
		return lid;
		
	    //generate using IDE	
	}
	public boolean equals(Object obj)
	{
		return false;
		
	}
	
	public int compareTo(Laptop1 l)
	{
		if(this.cost<l.cost)
			return -1;
		else if(this.cost>l.cost)
			return 1;
			else
				return 0;
	}
	
	class Laptop1Compare implements Comparator<Laptop1>
	{
		public int compare(Laptop1 l1, Laptop1 l2)
		{
			if(l1.getLid()<l2.getLid())
				return -1;
			else if(l1.getLid()<l2.getLid())
				return 1;
			else
				return 0;
		}
	}
	
}
public class Test1 {

	public static void main(String[] args) {
		Set<Laptop1> set=new TreeSet<>();
		set.add(new Laptop1(1,"dell",40000));
		set.add(new Laptop1(2,"apple",90000));
		set.add(new Laptop1(3,"hp",30000));
		set.add(new Laptop1(3,"hp",30000));
		
		for(Laptop1 l:set)
			l.display();

	}

}
