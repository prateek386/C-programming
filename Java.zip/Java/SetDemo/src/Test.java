import java.util.*;
class Laptop implements Comparable<Laptop>
{
	private int lid;
	private String make;
	private double cost;
	
	public Laptop()
	{
	}
	
	public Laptop(int lid, String make, double cost)
	{
		super();
		this.lid=lid;
		this.make=make;
		this.cost=cost;
	}
	
	public void display()
	{
		System.out.println(lid+" "+make+" "+cost);
	}
	
	public int hashCode()
	{
		return lid;
		
	    //generate using IDE	
	}
	public boolean equals(Object obj)
	{
		return false;
		
	}
	
	public int compareTo(Laptop l)
	{
		if(this.cost<l.cost)
			return -1;
		else if(this.cost>l.cost)
			return 1;
			else
				return 0;
	}
	
}
public class Test {

	public static void main(String[] args) {
		Set<Laptop> set=new TreeSet<>();
		set.add(new Laptop(1,"dell",40000));
		set.add(new Laptop(2,"apple",90000));
		set.add(new Laptop(3,"hp",30000));
		set.add(new Laptop(3,"hp",30000));
		
		for(Laptop l:set)
			l.display();

	}

}
