
class Vehicle implements Cloneable
{
	private int veh_no;
	private String veh_name;
	private double veh_price;
	
	public Vehicle()
	{
		
	}
	
	public Vehicle(int veh_no, String veh_name, double veh_price)
	{
		this.veh_no=veh_no;
		this.veh_name=veh_name;
		this.veh_price=veh_price;
	}
	
	public void display()
	{
		System.out.println("Your vehicle number is: "+veh_no);
		System.out.println("Your vehicle name is: "+veh_name);
		System.out.println("Your vehicle price is: "+veh_price);
	}
	
	public int hashCode()
	{
		return veh_no%10;
	}
	
	public boolean equals(Object obj)
	{
		Vehicle v=(Vehicle)obj;
		if(this.veh_no==v.veh_no && this.veh_name.equals(v.veh_name) && this.veh_price==v.veh_price)
		return true;
		else
			return false;
	}
	
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
}
public class Test {

	public static void main(String[] args) throws CloneNotSupportedException 
	{
		Vehicle v1=new Vehicle(10,"BMW",800000);
 	   Vehicle v2=(Vehicle)v1.clone();
 	   v2.display();
	}

}
