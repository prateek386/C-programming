class A
{
	public void fun()
	{
		System.out.println("fun");
	}
}
public class Test {

	public static void main(String[] args) {
		try
		{
			A a=null;
			a.fun();
			int []arr=new int[5];
			arr[7]=123;
		}
		catch(NullPointerException e)
		{
			System.out.println("Null Pointer Exception");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array index is invalid");
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}

	}

}
