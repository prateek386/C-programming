class Math
{
	public double fun1(int a, int b) throws Exception
	{
		return fun2(a, b);
	}
	
	public double fun2(int a, int b) throws Exception
	{
		return divide(a, b);
	}
	public double divide(int a, int b) throws Exception
	{
			if(b==0)
				throw new Exception("denominator is zero");
			return (double) a/b;
		}
	}

public class Test1 {

	public static void main(String[] args) {
		int a=10, b=0;
		Math m=new Math();
		try
		{
			System.out.println(m.fun1(a,b));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
