import java.util.Scanner;
class Test
{
       public static void main(String[] args)
{
            int a, b;
            Scanner sc=new Scanner(System.in);
           System.out.println("Enter the first number: ");
        a=sc.nextInt();
     System.out.println("Enter the second number: ");
        b=sc.nextInt();
System.out.println("Enter the operator:  ");
    char operator = sc.next().charAt(0);

  int c;
     switch(operator)
{
           case '+': c=a+b;
             System.out.println("Value of c is: "+c);
               break;
           
case '-': c=a-b;
             System.out.println("Value of c is: "+c);
               break;

case '*': c=a*b;
             System.out.println("Value of c is: "+c);
               break;

case '/': c=a/b;
             System.out.println("Value of c is: "+c);
               break;

default:System.out.println("Invalid numbers");
}
}
}

         