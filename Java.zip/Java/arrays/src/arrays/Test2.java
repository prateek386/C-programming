package arrays;
import java.util.Scanner;
public class Test2 {
         public static void main(String[] args)
         {
        	 Scanner sc=new Scanner(System.in);
        	 int [] arr=new int[10];
        	 
        	 System.out.println("Enter array element: ");
        	 for(int i=0;i<arr.length;i++)
        	 {
        		 arr[i]=sc.nextInt();
        	 }
        	 System.out.println("Array elements are: ");
        	 for(int i=0;i<arr.length;i++)
        	 {
        		 System.out.println(arr[i]+"   ");
        	 }
        	 System.out.println();
     		int []a= {1,2,3,4,5};
     		int []b=new int[] {5,4,3,2,1};
     		for(int i=0;i<5;i++)
     			System.out.println(b[i]);
         }
}
