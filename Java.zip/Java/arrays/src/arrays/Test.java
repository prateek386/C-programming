package arrays;

import java.util.Scanner;

//arrays - It is a collection of elements in same type
public class Test {

	public static void main(String[] args) {
		int [] arr=new int[10];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array element: ");
		for(int i=0;i<10;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Array element is: ");
		for (int i=0;i<10;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		int []a= {1,2,3,4,5};
		int []b=new int[] {5,4,3,2,1};
		for(int i=0;i<5;i++)
			System.out.println(a[i]);
	}

}
