import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
class MovingCircle extends Frame implements Runnable
{
	private int x1;
	private Thread t1;
	
	public MovingCircle()
	{
		x1=100;
		t1=new Thread(this,"red");
		t1.start();
	}
	
	public void paint(Graphics g)
	{
		g.setColor(Color.RED);
		g.fillOval(x1, 100, 100, 100);
		
		
	}
	
	public void run()
	{
			while(true)
			{
				if(Thread.currentThread()==t1)
				{
					synchronized(this)
					{
						x1++;
						if(x1==this.getWidth()-100)
						{
							try
							{
								wait();
							}
							catch(InterruptedException e)
							{
								e.printStackTrace();
							}
						}
					}
					try
					{
						Thread.sleep(25);
					}
					catch(InterruptedException e)
					{
						e.printStackTrace();
					}
				}
				
			repaint();
		}
	}
}

public  class Test {

	public static void main(String[] args) {
		MovingCircle mc=new MovingCircle();
		mc.setSize(600,600);
		mc.setVisible(true);

	}

}
