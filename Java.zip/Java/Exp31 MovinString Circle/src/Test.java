import java.awt.*;

public class Circle
{
	int x, y, width, height;
	Color c=Color.RED;
	
 public Circle(int x, int y, int width, int height, Color c)
 {
	 this.z=x;
	 this.y=y;
	 this.width=width;
	 this.c=c;
 }
 
 public void paint(Graphics g)
 {
	 g.setColor(c);
	 g.fillCircle(x, y)
 }
}