import java.awt.*;
import java.util.*;
import javax.swing.JFrame;

public class Game extends JFrame implements Runnable
{
	private static Circle myCircle;
	private static int numberOf
}
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
