import java.util.Scanner;
class Test
{
public static void main(String[] args)
{
             int num, i, j;
            Scanner sc=new Scanner(System.in);
             System.out.println("Enter the first number: ");
             num=sc.nextInt();
            for(i=1, j=10 ; i<=10;i++,j--)
{
           System.out.println(i+"    "+j);
}
}
}