class Account
{
	private int balance;
	
	public Account(int bal)
	{
		balance=bal;
	}
	
	public void deposite(int amount)
	{
		synchronized(this)
		{
			System.out.println("balance before deposite- "+balance);
			balance=balance+amount;
			System.out.println("balance after deposite-"+balance);
		}
	}
	
	public synchronized void withdraw(int amount)
	{
		System.out.println("balance before withdraw: "+balance);
		balance=balance-amount;
		System.out.println("balance after withdraw: "+balance);
	}
}

class AccountHolder extends Thread
{
	private String name, tot;
	private Account account;
	private int amount;
	
	public AccountHolder(String n, Account a, String tt, int amt)
	{
		name=n;
		account=a;
		tot=tt;
		amount=amt;
	}
	
	public void run()
	{
		if(tot.equals("deposite"))
			account.deposite(amount);
		else if(tot.equals("withdraw"))
			account.withdraw(amount);
	}
}
public class Test {

	public static void main(String[] args) {
		Account acc=new Account(4000);
		AccountHolder user1=new AccountHolder("user1", acc,"deposite",5000);
		AccountHolder user2=new AccountHolder("user2",acc,"withdraw",4000);
		user1.start();
		user2.start();

	}

}
