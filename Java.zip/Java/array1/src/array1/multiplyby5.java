package array1;

import java.util.Scanner;

public class multiplyby5 {
	

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		for(int i=0;i<5;i++)
		{
		       System.out.println(a[i]+" ");
		}
		System.out.println();
	    int b[]=new int[5];
	    for(int i=0;i<a.length;i++)
	    {
	    	int result=a[i]*5;
	    	b[i]=result;
	    	 System.out.println(b[i]+" ");
	    }
	    
		}

}
