package array1;

import java.util.Scanner;

public class Test4 {
	  public int max(int[] arr)
	  {
		  int max=0;
		  for(int i=0;i<arr.length;i++)
		  {
			  if(arr[i]>max)
			  {
				  max=arr[i];
			  }
		  }
		  return max;
	  }  
		public int min(int[] arr)
		{
	      int min=arr[0];
		  for(int i=0;i<arr.length;i++)
		  {
			  if(arr[i]<min)
			  {
				  min=arr[i];
			  }
		  }
		  return min;
	  }

	public static void main(String[] args) {
		int []arr=new int[5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the array element: ");
		for(int i=0;i<5;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Array eleemnt is: ");
		for(int i=0;i<5;i++)
		{
			System.out.println(arr[i]+"   ");
		}
		
		Test4 m=new Test4();
		System.out.println("The maximum number is: "+m.max(arr));
		System.out.println("The minimum number is: "+m.min(arr));

	}

}
