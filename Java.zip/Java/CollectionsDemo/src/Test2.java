import java.util.*;

class Employee
{
	
}
public class Test2 {

	public static void main(String[] args)
	{
		List<Employee> elist=new ArrayList<Employee>();
	    List<Integer> list = new ArrayList<>();
	    list.add(12);
	    list.add(1);
	    list.add(6);
	    list.add(10);
	    list.add(7);
	    
	    System.out.println(list);
	    Collections.sort(list);
	    System.out.println(list);

	}

}
