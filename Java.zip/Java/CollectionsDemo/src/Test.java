import java.util.*;
public class Test {

	public static void main(String[] args) {
		Vector<Integer> v=new Vector<>();
		v.add(10);
		v.add(20);
		v.add(30);
		v.add(40);
		v.add(50);
		
		System.out.println(v);
		
		for(Integer x:v)
		{
			System.out.print(x+" ");
		}
		System.out.println();
		
		Iterator itr=v.iterator();
		while(itr.hasNext())
		{
			System.out.print(itr.next()+" ");
		}
System.out.println();
	}

}
