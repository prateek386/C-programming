import java.util.*;
public class Test1 {

	public static void main(String[] args) {
		Set<Integer> s=new HashSet<>();
        s.add(12);
        s.add(24);
        s.add(36);
        s.add(48);
        s.add(22);
        
        System.out.println(s+" ");
	}

}
