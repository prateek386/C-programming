class Student implements Cloneable
{
	private int rollno;
	private String name;
	private double percentage;
	
	public Student()
	{
	}	
   
	public Student(int rollno, String name, double percentage)
	{
		this.rollno=rollno;
		this.name=name;
		this.percentage=percentage;
	}
	
	public void display()
	{
		System.out.println("Your rollno is: "+rollno);
		System.out.println("Your name is: "+name);
		System.out.println("Your percentage is: "+percentage);
	}
	
	public int hashCode()
	{
		return rollno%10;
	}
	
	public boolean equals(Object obj)
	{
		Student s=(Student)obj;
		if(this.rollno==s.rollno && this.name.equals(s.name) && this.percentage==s.percentage)
			return true;
		else
			return false;
	}
	
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
}
public class Test {
           public static void main(String[] args) throws CloneNotSupportedException
           {
        	   Student s1=new Student(1,"tushar",60);
        	   Student s2=(Student)s1.clone();
        	   s2.display();
           }
}

