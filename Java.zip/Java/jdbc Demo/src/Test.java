import java.sql.*;
class Test {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded...");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			Statement stmt=conn.createStatement();
			ResultSet rset=stmt.executeQuery("select * from student");
			
			while(rset.next())
			{
				System.out.println(rset.getInt(1)+"  "+rset.getString(2)+"  "+rset.getDouble(3));
			}
			stmt.close();
			conn.close();
			
		}
		catch(Exception e)
		{
		     e.printStackTrace();	
		}

	}

}
