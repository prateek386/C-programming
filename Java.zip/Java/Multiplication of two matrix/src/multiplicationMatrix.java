import java.util.Scanner;
public class multiplicationMatrix {

	public static void main(String[] args) {
		
		         
		        	  int a[][]= {{1,2,3},{3,6,2}};
		        	  int b[][]= {{2,7,5},{1,2,3},{1,9,6}};
		        	  int sum=0;
		        	  int c[][]=new int[3][3];
		        	  for(int i=0;i<3;i++)
		        	  {
		        		  for(int j=0;j<3;j++)
		        		  {
		        			  for(int k=0;k<3;k++)
		        			  {
		        				sum=sum+a[i][j]*b[k][j];  
		        			  }
		        			  c[i][j]=sum;
		        			  sum=0;
		        		  }
		        	  }
		          }
		
}
	


