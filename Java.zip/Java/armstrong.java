import java.util.Scanner;
class Armstrong
{
           public static void main(String[] args)
{
          int a;
          int temp;
          int c=0;
          int n;
          temp=n
          Scanner sc=new Scanner(System.in);
           System.out.println("Enter the number: ");
             n=sc.nextInt();
         while(n>0){
              a=n%10;
              n=n/10;
              c=c+(a*a*a);
         }
if(temp==c)
{
         System.out.println("The number " + c + "is armstrong");
}
    else
{
           System.out.println("It is not an armstrong");
}
}
}