
import java.util.Scanner;
//Varags = Variable arguments
//Variable Arguments should be the last arguments of that method
public class Varags {
	public static void add(String str,int...a)
	{
		int result=0;
		for(int i=0;i<a.length;i++)
		{
			result=result+a[i];
		}
		System.out.println(str+result);
	}
	public static void main(String[] args) 
	{
	       add("Addition is:",45,60,70);	

	}

}
