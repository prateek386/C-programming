import java.util.Scanner;
class Test{
       public static void main(String[] args)
{
          int num, i;
        Scanner sc = new Scanner(System.in);
         System.out.println("Enter your number: ");
          num = sc.nextInt();
   
     System.out.println("Table-");
      /* i=1
           while(i<=10)
           {
                      System.out.println(num*i);
          i++;
         }*/
   for(i=1;i<=10;i++)
  {
          System.out.println(num*i);
   }
       
    }
}
       