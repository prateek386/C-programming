import java.util.Scanner;

public class array {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int []a1= {1,2,3,4,5};               //ini
		int []a2= new int[] {1,2,3,4,5};     //ini
		int []a3= new int[10];               //uni-ini
		
		int [][]b1 = {{1,2,3},{4,5,6},{7,8,9}};                //ini
		int [][]b2 = new int[][] {{1,2,3},{4,5,6},{7,8,9}};   //ini
        int [][]b3 = {{1,2,3},{4,5,6},{7,8,9}}; //ini jagged array
        
        System.out.print("Enter the number of rows: ");
        int [][]b4=new int[sc.nextInt()][];
        for(int i=0;i<b4.length;i++)
        {
        	System.out.println("Enter the number of columns:");
        	b4[i]=new int[sc.nextInt()];
        }
        System.out.println("Enter the array element: ");
        for(int i=0;i<b4.length;i++)
        {
        	for(int j=0;j<b4[i].length;j++) 
        	{
        	          b4[i][j]=sc.nextInt();	
        	}
        }
         for(int i=0;i<b4.length;i++)
         {
        	 for(int j=0;j<b4[i].length;j++)
        	 {
        		 System.out.print(b4[i][j]+" " );
        	 }
        	 System.out.println();
         }
	}
}
         