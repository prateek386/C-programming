class Date
{
	private int dd, mm, yy;
	
	public Date()
	{
		dd=1;
		mm=1;
		yy=2000;
	}
	
	public Date(int d, int m, int y)
	{
		dd=d;
		mm=m;
		yy=y;
	}
	
	public void display()
	{
		System.out.println(dd+"/"+mm+"/"+yy);
	}
}

class Employee
{
	private int empid;
	private String name;
	private Date dob;
	
	public Employee()
	{
		empid=1;
		name="abc";
		dob = new Date();
	}
	
	public Employee(int id, String n, int d, int m, int y)
	{
		empid=id;
		name=n;
		dob=new Date(d,m,y);
	}
	
	public void display()
	{
		System.out.println("EmpID is: "+empid);
		System.out.println("EmpName is: "+name);
		dob.display();
		System.out.println();
	}
}

class WageEmployee extends Employee
{
	private int hours;
	private int rate;
	
	public WageEmployee()
	{
		super();
		hours=0;
		rate=0;
	}
	
	public WageEmployee(int id, String n, int d, int m, int y, int h, int r)
	{
		super(id, n, d, m, y);
		hours=h;
		rate=r;
	}
	
	public int Salary()
	{
		int Salary=0;
		Salary = hours*rate;
		return Salary;
	}
	

	public void display()
	{
		super.display();
		System.out.println("The hour is: " + hours);
		System.out.println("The rate is: " + rate);
		System.out.println("The WageSalary is: " + Salary());
		System.out.println();
		
	}
}

class SalesPerson extends WageEmployee
{
	
	private int item;
	private int Commission;
	
	public SalesPerson()
	{
		super();
		this.item=0;
		this.Commission=0;
	}
	
	public SalesPerson(int id, String n, int d, int m, int y,int h, int r, int item, int Commission)
	{
		super(id, n, d, m, y, h, r);
		this.item=item;
		this.Commission=Commission;
	}
	
	public int Salary(int hours, int rate)
	{
		int salary=0;
		salary =salary+hours*rate + item*Commission;
		return salary;
	}
	
	

	public void display()
	{
		super.display();
		System.out.println("Item number is: "+item);
		System.out.println("Commission per item is: "+Commission);
		System.out.println("The SalesPersonSalary is: "+Salary());
	}
	
}
public class Test {

	public static void main(String[] args) 
	{
		
		Employee e1=new Employee(200, "ashok", 15, 4, 1995);
		e1.display();

		WageEmployee we=new WageEmployee(300, "ben", 10, 10, 2010, 5, 800);
		we.display();
		
		SalesPerson se=new SalesPerson(400," Rex", 11, 8, 1991, 5, 1000, 45, 2000);
		se.display();
		
	}

}
