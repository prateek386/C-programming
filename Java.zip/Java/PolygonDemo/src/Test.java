interface Polygon
{
	double calcArea();
	double calcPeri();
}
class Circle implements Polygon
{
	private int radius;
	
	public Circle()
	{
		radius=1;
	}
	
	public Circle(int rad)
	{
		radius=rad;
	}
	
	public double calcArea()
	{
		return 3.142*radius*radius;
	}
	
	public double calcPeri()
	{
		return 2*3.142*radius;
	}
}

class Rectangle implements Polygon
{
	private int length, breadth;
	
	public Rectangle()
	{
		length=breadth=1;
	}
	
	public Rectangle(int len, int brd)
	{
		length=len;
		breadth=brd;
	}
	
	public double calcArea()
	{
		return length*breadth;
	}
	
	public double calcPeri()
	{
		return 2*(length+breadth);
	}
}

class Square extends Rectangle
{
	public Square()
	{
		super();
	}
	
	public Square(int s)
	{
		super(s,s);
	}
	public double calcArea()
	{
		return super.calcArea();
	}
	public double calcPeri()
	{
		return super.calcPeri();
	}
}
public class Test {

	public static void main(String[] args)
	{
	       Polygon c=new Circle(12);
	       System.out.println("area: "+c.calcArea());
	       
	       Polygon r=new Square(15);
	       System.out.println("perimeter: "+r.calcPeri());

	}

}
