import java.util.Scanner;

class MyThread implements Runnable
{
	private int num;
	public Thread t1, t2;

	public MyThread(int n)
	{
		num=n;
		t1=new Thread(this,"incr");
		t2=new Thread(this, "table");
		t1.start();
		t2.start();
	}
	
	public void run()
	{
		for(int i=0;i<10;i++)
			if(Thread.currentThread()==t1)
				System.out.println("The number is: "+num+i);
			else if(Thread.currentThread()==t2)
				System.out.println("The number is: "+num*i);
	}
}

public class Test {

	public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter your number: ");
	  new MyThread(sc.nextInt());
	  

	}

}