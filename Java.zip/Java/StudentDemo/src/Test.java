class Student
{
	private int rollno;
	private String name;
	private double percentage;
	
	public Student()
	{
		
	}
	
	public Student(int rollno, String name, double percentage)
	{
		this.rollno=rollno;
		this.name=name;
		this.percentage=percentage;
	}
	
	public void display()
	{
		System.out.println("Your rollno is: "+rollno);
		System.out.println("Your name is: "+name);
		System.out.println("Your percentage is: "+percentage);
	}
	
	public int hashCode()
	{
		return rollno%10;
	}
	
	public boolean equals(Object obj)
	{
		Student s=(Student)obj;
		if(this.rollno==s.rollno && this.name.equals(s.name) && this.percentage==s.percentage)
			return true;
		else
			return false;
	}
}
public class Test {
	public static void main(String[] args)
	{
		Student s1=new Student(101,"jay",65);
		Student s2=new Student(101,"jay",65);
		
		if(s1.equals(s2))
			System.out.println("same");
			else
				System.out.println("different");
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
	}

}
