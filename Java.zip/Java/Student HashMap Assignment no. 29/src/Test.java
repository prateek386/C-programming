import java.util.*;

class Student implements Comparable<Student>
{
	private int rollno;
	private String name;
	private double percentage;
	private Set<String> skillset;
	
	public Student()
	{
	}
	
	public Student(int no, String name, double percentage)
	{
		this.rollno=no;
		this.name=name;
		this.percentage=percentage;
	}
	
	public void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your rollno: ");
		rollno=sc.nextInt();
		System.out.println("Enter your name: ");
		name=sc.next();
		System.out.println("Enter your percentage: ");
		percentage=sc.nextDouble();
	}
	
	public int hashCode()
	{
		return rollno;	
	}
	
	public boolean equals(Object obj)
	{
		return false;
		
	}
	
	public int compareTo(Student s)
	{
		if(this.percentage<s.percentage)
			return -1;
		else if(this.percentage>s.percentage)
			return 1;
			else
				return 0;
	}
	
	public void display()
	{
	     System.out.println("Your rollno is: "+rollno);
	     System.out.println("Your name is: "+name);
	     System.out.println("Your percentage is: "+percentage);
	} 
}

class UtilityList
{
	private List<Student> list;
	
	public void createList()
	{
		Student s=new Student();
		s.accept();
		list.add(s);
	}
	
	public void printList()
	{
		for(Student s:list)
		{
		       s.display();
		}
	}
	
	
}
public class Test {

	public static void main(String[] args) {
	Set<Student> set=new TreeSet<>();
	set.add(new Student(10,"Ben",53.0));
	set.add(new Student(20,"Rex",75.0));
	
	for(Student s:set)
		s.display();
	
	
	}

}
