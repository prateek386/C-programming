import java.util.*;
class Marks
{
        public static void main(String[] args)
{
        int a, b, c, d, e;
     System.out.println("Enter your first number: ");
     Scanner sc=new Scanner(System.in);
     a=sc.nextInt();
     System.out.println("Enter your second number: ");
     b=sc.nextInt();
     System.out.println("Enter your third number: ");
     c=sc.nextInt();
     System.out.println("Enter your fourth number: ");
     d=sc.nextInt();
     System.out.println("Enter your fifth number: ");
     e=sc.nextInt();

     int avg = (a+b+c+d+e)/5;

      System.out.println("The avergage number is: "+avg);
  }
}
