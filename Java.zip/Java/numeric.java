class Test
{
    public static void main(String[] args)
{
     int a=22;
     a%=5;
     System.out.println(a);
}
}