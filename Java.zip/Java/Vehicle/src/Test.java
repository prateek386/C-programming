class Vehicle
{
	private int veh_no;
	private String veh_name;
	private double veh_price;
	
	public Vehicle()
	{
		
	}
	
	public Vehicle(int veh_no, String veh_name, double veh_price)
	{
		this.veh_no=veh_no;
		this.veh_name=veh_name;
		this.veh_price=veh_price;
	}
	
	public void display()
	{
		System.out.println("Your vehicle number is: "+veh_no);
		System.out.println("Your vehicle name is: "+veh_name);
		System.out.println("Your vehicle price is: "+veh_price);
	}
	
	public int hashCode()
	{
		return veh_no%10;
	}
	
	public boolean equals(Object obj)
	{
		Vehicle v=(Vehicle)obj;
		if(this.veh_no==v.veh_no && this.veh_name.equals(v.veh_name) && this.veh_price==v.veh_price)
			return true;
		else
			return false;
	}
}
public class Test {
	public static void main(String[] args)
	{
		Vehicle v1=new Vehicle(101,"Mercedes",780000);
		Vehicle v2=new Vehicle(102,"Toyota",6500000);
		
		if(v1.equals(v2))
			System.out.println("same");
			else
				System.out.println("different");
		
		System.out.println(v1.hashCode());
		System.out.println(v2.hashCode());
	}

}
