interface printable
{
	public void printDetails();
}

		class CktPlayer implements printable
		{
			private String name;
			private int runs;
			
			public CktPlayer()
			{
				this.name="Ben";
				this.runs=423;
			}
			
			public CktPlayer(String name, int runs)
			{
				super();
				this.name=name;
				this.runs=runs;
			}
			
			public void printDetails()
			{
				System.out.println("Name is: "+name);
				System.out.println("Runs scored: "+runs);	
			}
		}		
			class FtPlayer implements printable
			{
			      private String name;
			      private int goals;
			      
			      public FtPlayer()
			      {
			    	  this.name="Ben";
			    	  this.goals=1;
			      }
			      
			      public FtPlayer(String name, int goals)
			      {
			    	  super();
			    	  this.name=name;
			    	  this.goals=goals;
			      }
			      
			      public void printDetails()
			      {
			    	  System.out.println("Name is: "+name);
			    	  System.out.println("Goals scored: "+goals);
			      }
			}

public class Test {

	public static void main(String[] args) {
		FtPlayer f1=new FtPlayer();
		f1.printDetails();
		
		CktPlayer c=new CktPlayer();
		c.printDetails();

	}

}
