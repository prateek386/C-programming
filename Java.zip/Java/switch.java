import java.util.Scanner;
class Test
{
    public static void main(String[] args)
{
      Scanner sc = new Scanner(System.in);
int num;
System.out.println("Enter the number: ");
num = sc.nextInt();

switch(num)
{
       case 1:System.out.println("One");
   break;
  case 2: System.out.println("Two");
     break;
   case 3: System.out.println("This is third case");
     break;
   case 4: System.out.println("This is fourth case");
     break;
 default: System.out.println("Invalid case");
     break;
}
String str = "third";
switch(str)
{
     case "a" : System.out.println("This is first case");
     break;
     case "b" : System.out.println("This is second case");
     break;
     case "c" : System.out.println("This is third case");
     break;
     case "d" : System.out.println("This is fourth case");
     break;
     default : System.out.println("Nothing");
     break;
}
}
}