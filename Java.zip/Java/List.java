// import java.util.Scanner;
public class List {
    public static void main(String args[])
    {
        // Scanner sc = new Scanner(System.in);
        // System.out.println("Enter your number: ");
        // int n = sc.nextInt();
        int n;

        for(int i = 1; i<=10; i++)
        {
            System.out.println(i);
        }
    }
}
