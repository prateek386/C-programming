import java.util.*;

class Student
{
	private int rollno;
	private String name;
	private double percentage;
	private Set<String> skillset;
	
	public String getName()
	{
		return name;
	}
	
	public double getPercentage()
	{
		return percentage;
	}
	
	public Student()
	{
		skillset=new LinkedHashSet<>();
	}
	
	public void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter roll no: ");
		rollno=sc.nextInt();
		System.out.println("Enter your name: ");
		name=sc.next();
		System.out.println("Enter your percentage: ");
		percentage=sc.nextDouble();
		
		System.out.println("Enter 3 skillset: ");
		skillset.add(sc.next());
		skillset.add(sc.next());
		skillset.add(sc.next());
	}
	
	public void display()
	{
		System.out.println(rollno+" "+name+" "+percentage+" "+skillset);
	}
	
}

class UtilityList
{
	private List<Student> list;
	
	public List<Student> getList()
	{
		return list;
	}
	
	public UtilityList()
	{
		list=new ArrayList<>();
	}
	
	public void createList()
	{
		Student s;
		System.out.println("Enter information of 3 student: ");
		for(int i=0;i<3;i++)
		{
			s=new Student();
			s.accept();
			list.add(s);
		}
	}
	
	public void printList()
	{
		for(Student s:list)
		{
			s.display();
		}
	}
}

class UtilityReport
{
	private Map<String, Double> m;
		public UtilityReport(List<Student> list)
		{
			m=new LinkedHashMap<>();
					for(Student s:list)
					{
						m.put(s.getName(), s.getPercentage());
					}
		}
		public void showReport()
		{
			System.out.println(m);
		}
}
public class Test1 {

	public static void main(String[] args) {
		UtilityList ul=new UtilityList();
		ul.createList();
		ul.printList();
		UtilityReport ur=new UtilityReport(ul.getList());
		ur.showReport();

	}

}
