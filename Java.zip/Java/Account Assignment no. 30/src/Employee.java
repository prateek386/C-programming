
public class Employee {

	      public int acc_no;
	      public String acc_name;
	      public double acc_balance;
	      public Employee(int no,String name,double balance)
	      {
		      this.acc_no=no;
		      this.acc_name=name;
		      this.acc_balance=balance;
	      }
	public String toString()
	{
		return "Employee [acc_no=" + acc_no + ", acc_name=" + acc_name + ", acc_balance=" + acc_balance + "]";
	}
	}
