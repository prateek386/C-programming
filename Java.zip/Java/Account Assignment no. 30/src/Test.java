class Account
{
	private int balance;
	
	public Account()
	{
		balance=10000;
	}
	
	public Account(int bal)
	{
		balance=bal;
	}
	
	public void deposite(int amount)
	{
		balance=balance+amount;
	}
	public void withdraw(int amount) throws Exception
	{
		if(amount>balance)
			throw new Exception("InsufficientBalance");
		if(amount>15000)
			throw new Exception("Overlimit");
		balance=balance-amount;
	}
}
public class Test {

	public static void main(String[] args) {
           Account ac=new Account(50000);
           
           try
           {
        	   ac.withdraw(20000);
           }
           catch(Exception e)
           {
        	   System.out.println("Insufficient amount");
           }
           

	}

}
