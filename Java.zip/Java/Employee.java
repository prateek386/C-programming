import java.util.*;
class Employee
{
         public static void main(String[] args)
{
       double HRA, DA,  PF, BS, GS, net_salary;
       System.out.println("Enter your BS number: ");
       Scanner sc = new Scanner(System.in);
       BS = sc.nextDouble();


 HRA = 0.15 * BS;
System.out.println("HRA is: "+HRA);
    
DA = 0.30 * BS;
System.out.println("DA is: "+DA);

GS = BS+HRA+DA;
System.out.println("GS is : "+GS);

    PF = 0.125 * GS;
System.out.println("PF is: "+PF);


net_salary = GS - PF;
System.out.println("Net Salary is: "+net_salary);
}
}