import java.sql.*;
public class Test {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded...");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected...");
						
			//Insert into student
			String sql="insert into student (rollno, name, percentage)values(?,?,?)";
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1, 101);
			statement.setString(2, "abc");
			statement.setDouble(3, 60);
			
			int rowsInserted=statement.executeUpdate();
			if(rowsInserted>0)
			{
				System.out.println("One record was inserted successfully");
			}
			
			//Display record
			Statement statement4=conn.createStatement();
			ResultSet rset=statement4.executeQuery("select * from student");
			while(rset.next())
			{
				System.out.println(rset.getInt(1)+" "+rset.getString(2)+" "+rset.getDouble(3));
			}
			
			//Update record
			String sql2="update student set percentage=? where rollno=?";
			PreparedStatement statement2=conn.prepareStatement(sql2);
			statement2.setDouble(1, 60);
			statement.setInt(2, 87);
			int rowUpdate=statement2.executeUpdate();
			if(rowUpdate>0)
			{
				System.out.println("Record updated successfully");
			}
			
			//Delete record
			String sql3="delete from student where rollno=?";
			PreparedStatement statement3=conn.prepareStatement(sql3);
			statement3.setInt(1, 101);
			int rowDeleted=statement3.executeUpdate();
			if(rowDeleted>0)
			{
			     System.out.println("Record deleted successfully");	
			}
					
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
