class Laptop
{
	private int lid;    //instance variables/attributes/data members
	private String make;
	private double cost;
	
	void init()
	{
		lid=1;
		make="dell";          //methods/getter or setter
		cost=35000;
	}
	
	public Laptop()           //default constructor
	{
		lid=1;
		make="dell";          
		cost=35000;
	}
public Laptop(int lid, String make, double cost)
{
	this.lid=lid;
	this.make=make;
	this.cost=cost;
}
public double getCost()
{
	return cost;
}

public void setCost(double cost)
{
	this.cost=cost;
}
public void display()
{
	System.out.println(lid);
	System.out.println(make);
	System.out.println(cost);
}

@Override
public String toString() {
	return "Laptop [lid=" + lid + ", make=" + make + ", cost=" + cost + "]";
}
}
public class Test1
{
	public static void main(String[] args)
	{
		Laptop l1=new Laptop(2, "apple", 70000);
		l1.setCost(75000);
		System.out.println(l1);
	}
	
}