//class Laptop
//{
//	private int lid;    //instance variables/attributes/data members
//	private String make;
//	private double cost;
	
//	void init()
//	{
//		lid=1;
//		make="dell";          //methods
//		cost=35000;
//	}
	
//	public Laptop()           //default constructor
//	{
//		lid=1;
//		make="dell";          
//		cost=35000;
//	}
//	public Laptop(int id, String m, double c)  //parameterised constructor
//	{
//		lid=id;
//		make=m;
//	cost=c;
//	}
//	void display()
//	{
//		System.out.println(lid);
//		System.out.println(make);      
//		System.out.println(cost);
//	}
//}

public class Test {

	public static void main(String[] args) 
	{
		Laptop l1=new Laptop(2,"apple",700000);
        l1.display();
        
        Laptop l2=new Laptop();
        l2.display();
        
	}

}
