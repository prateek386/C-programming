import com.pack1.Student;
import static com.pack1.Student.showCnt;
import static java.lang.System.out;

public class Test {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.setRollno(10);
		s1.setName("Ben");
		s1.setPercentage(0.15);
		System.out.println(s1);
		
		Student s2=new Student();
		s2.setRollno(20);
		s2.setName("Rex");
		s2.setPercentage(0.18);
		System.out.println(s2);
		
		Student s3=new Student();
		s3.setRollno(30);
		s3.setName("Noah");
		s3.setPercentage(0.30);
		System.out.println(s3);
		
		showCnt();
		out.println("test print....");
		
	}

}
