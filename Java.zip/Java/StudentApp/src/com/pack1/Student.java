package com.pack1;

public class Student
{
	private int rollno;
	private String name;
	private double percentage;
	private static int cnt;
	
	public Student()
	{
		cnt++;
	}
	
	public Student(int rollno, String name, double percentage)
	{
		this.rollno=rollno;
		this.name=name;
		this.percentage=percentage;
		cnt++;
	}
	public double getRollno()
	{
		return rollno;
	}
	public String getName()
	{
		return name;
	}
	public double getPercentage()
	{
		return percentage;
	}
	
	public void setRollno(int rollno)
	{
		this.rollno=rollno;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	
	public void setPercentage(double percentage)
	{
		this.percentage=percentage;
	}
	
	
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", percentage=" + percentage + "]";
	}
	public void display()
	{
		System.out.println(rollno);
		System.out.println(name);
		System.out.println(percentage);
	}
	
	
	public static void showCnt()
	{
		System.out.println(cnt);
	}
	
}
