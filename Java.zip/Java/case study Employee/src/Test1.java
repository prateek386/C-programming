import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

class admin
{
	public void insert()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your acc_no: ");
		int acc_no=sc.nextInt();
		System.out.println("Enter your name: ");
		String acc_name=sc.next();
		System.out.println("Enter your acc_balance: ");
		double acc_balance=sc.nextDouble();
		try
		{
				
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			
			String sql="insert into Bank_System values('"+acc_no+"', '"+acc_name+"', '"+acc_balance+"')";
			PreparedStatement stmt=conn.prepareStatement(sql);
			
			int x=stmt.executeUpdate(sql);
			System.out.println("Record inserted....");
			
			stmt.close();
			conn.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your acc_no to be updated: ");
			int no=sc.nextInt();
			System.out.println("Enter new name: ");
			String newname=sc.next();
			System.out.println("Enter new balance: ");
			double newbalance=sc.nextDouble();
			
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			Statement stmt=conn.createStatement();
			
			String sql1="update Bank_System set acc_name='"+newname+"' where acc_no='"+no+"'";
			int x=stmt.executeUpdate(sql1);
			
			String sql2="update Bank_System set acc_balance='"+newbalance+"' where acc_no='"+no+"'";
			int x2=stmt.executeUpdate(sql2);
			
		   stmt.close();
		   conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void delete()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your acc_no to be deleted: ");
		int no=sc.nextInt();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			Statement stmt=conn.createStatement();
			
			String q1="delete from Bank_System where acc_no='"+no+"'";
			int x=stmt.executeUpdate(q1);
			stmt.close();
			conn.close();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void displayRecord()
	{
		Scanner sc=new Scanner(System.in);
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Bank_System");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
			}
			stmt.close();
			conn.close();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

class Customer
{
	public void deposite()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Emnter your acc_no: ");
		int no=sc.nextInt();
		System.out.println("Enter the amount to be deposited: ");
		double amount=sc.nextDouble();
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Bank_System where acc_no='"+no+"'");
			double balance=0;
			if(rs.next())
			{
				balance=balance+rs.getDouble(3);
			}
			String sql2="update Bank_System set acc_balance='"+(balance+amount)+"' where acc_no='"+no+"'";
			int x2=stmt.executeUpdate(sql2);
			System.out.println("Record deposited...");
			
			
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void withdraw()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your acc_no: ");
		int no=sc.nextInt();
		System.out.println("Enter your amount to be withdraw: ");
		double amount=sc.nextDouble();
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			
			Statement stmt=conn.createStatement();
			ResultSet rs1=stmt.executeQuery("select * from Bank_System where acc_no='"+no+"'");
			double balance=0;
			if(rs1.next())
			{
				balance=balance+rs1.getDouble(3);
			}
			String q2="update Bank_System set acc_balance='"+(balance-amount)+"'where acc_no='"+no+"'";
			int x2=stmt.executeUpdate(q2);
			System.out.println("Record withdrawn...");
			
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void checkbal()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your acc_no: ");
		int no=sc.nextInt();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","yash@1211");
			System.out.println("connected....");
			
			Statement stmt=conn.createStatement();
			ResultSet rs1=stmt.executeQuery("select * from Bank_System where acc_no='"+no+"'");
			while(rs1.next())
			{
				System.out.println(rs1.getDouble(3));
			}
			stmt.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
public class Test1 {

	public static void main(String[] args) {
		int ch;
		admin a=new admin();
		Customer c=new Customer();
		int ex;
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("1. admin");
			System.out.println("2.customer");
			System.out.println("Enter your choice: ");
			ch=sc.nextInt();
		
			switch(ch)
			{
		  
					case 1:
					char ch1;
					System.out.println("***********Login as an admin***************");
					System.out.println("a) Insert record: ");
					System.out.println("b) Modify the Customer Details record: ");
					System.out.println("c) Delete record: ");
					System.out.println("d) Display all the record: ");
					System.out.println("Enter your choice: ");
					ch1=sc.next().charAt(0);
					switch(ch1)
					{
						case 'a':
							a.insert();
							break;
			         
						case 'b':
							a.update();
							break;
				
						case 'c':
							a.delete();
							break;
				
						case 'd':
							a.displayRecord();
							
			}
					break;
		
			
		case 2:
			System.out.println("*******Login as a customer************");
			System.out.println("a) Deposite amount: ");
			System.out.println("b) Withdraw amount: ");
			System.out.println("c) Check balance: ");
			System.out.println("Enter your choice: ");
			char ch2=sc.next().charAt(0);
			switch(ch2)
			{
			case 'a':
				c.deposite();
				break;
				
			case 'b':
				c.withdraw();
				break;
				
			case 'c':
				c.checkbal();
				break;
			}
			break;
				default:
					System.out.println("Invalid number");		
			}
			System.out.println("Do you want to continue?: 1)yes 2)no");
			ex=sc.nextInt();
		}
		while(ex==1);
	}
	}
	




