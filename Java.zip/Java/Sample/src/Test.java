
class Date {
	private int dd,mm,yy;
	
	public Date() {
		dd=1;
		mm=1;
		yy=2000;
	}
	public Date(int d, int m, int y) {
			dd=d;
			mm=m;
			yy=y;
		}
		
		public void display() {
			System.out.println(dd+"/"+mm+"/"+yy);
		}
	
}

class Employee {
	private int empid;
	private String name;
	private Date dob;
	
	public Employee() {
		empid=1;
		name="abx";
		dob=new Date();
	}
	
	public Employee(int id, String n, int d, int m, int y) {
		empid=id;
		name=n;
		dob =new Date(d,m,y);
	}
	public void display() {
		System.out.println("Employee id= "+empid);
		System.out.println("Name = "+name);
		dob.display();
	}
}

class WageEmployee extends Employee {
	private int hours;
	private int rate;
	
	public WageEmployee() {
		super();
		hours=0;
		rate=0;
	}
	
	public WageEmployee(int id, String n, int d, int m, int y, int h, int r) {
		super(id,n,d,m,y); 
		hours=h;
		rate=r;
	}
	public int salary() {
		int salary=0;
		salary=salary+hours*rate;
		return salary;
	}
	public void display() {
		super.display();
		System.out.println("No. of hours worked = "+hours);
		System.out.println("Rate= "+rate);
		System.out.println("Total salary is ="+salary());
	}
}

class SalesPerson extends WageEmployee {
	private int itemsSold,comm;
	
	public SalesPerson() {
		super();
		this.itemsSold=0;
		this.comm=0;
		
	}
	
	public SalesPerson(int id, String n, int d, int m, int y, int h, int r, int item, int commision) {
		super(id,n,d,m,y,h,r);
		this.itemsSold=item;
		this.comm=commision;
	}
	public int salary(int hours, int rate ) {
		int salary=0;
		salary=salary+hours*rate+itemsSold*comm;
		return salary;
	}
	public void display() {
		super.display();
		System.out.println("N0. of items sold = "+itemsSold);
		System.out.println("Commission earned = "+comm);
		System.out.println("Total salary = "+salary());
	}
}
	
public class Test {

	public static void main(String[] args) {
		Employee e1= new Employee(200,"Ashok",15,2,1995);
				e1.display();
				
		WageEmployee we = new WageEmployee(300,"Swati",10,10,1990,10,1000);
		we.display();
		
		SalesPerson sp = new SalesPerson(300,"Ravi",14,8,2000,20,2000,45,200);
		sp.display();
	}

}