class Demo<G>
{
	public void Swap(G a, G b)
	{
		G temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println(a+"  "+b);
	}
}
public class Test
{
	public static void main(String[] args) 
	{
		Demo<Integer> d=new Demo<Integer>();
		d.Swap(10, 20);
		
		Demo<String> d2=new Demo<String>();
		d2.Swap("java" , "cpp");

	}

}