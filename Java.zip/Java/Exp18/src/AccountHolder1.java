import java.util.*;

class AccountHolder
{
	private int accno;
	private String accname;
	private int accbalance;
    

public AccountHolder()
{
	
}

public AccountHolder(int accno, String accname, int accbalance)
{
	this.accno=accno;
	this.accname=accname;
	this.accbalance=accbalance;
}

public int getAccno()
{
	return accno;
}



public void withdraw(int amount)
{
	accbalance=accbalance-amount;
}

public void deposite(int amt)
{
	accbalance=accbalance+amt;
}

public void accept()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter account number: ");
	accno=sc.nextInt();
	System.out.println("Enter account holder name: ");
	accname=sc.next();
	System.out.println("Enter account balance: ");
	accbalance=sc.nextInt();
}


public void display()
{
	System.out.print(accno+"    "+accname+"   "+accbalance);
	System.out.println();
	
}

}
public class AccountHolder1 {

	public static void main(String[] args) {
		     int choice, cnt=0;
		     Scanner sc=new Scanner(System.in);
             AccountHolder[] acc = new AccountHolder[5];
		     
             for(int i=0;i<acc.length;i++)
            	 acc[i]=new AccountHolder();
                
                 while(true)
                 {
                	 System.out.println("1. Add Record");
                	 System.out.println("2. Display all records");
                	 System.out.println("3. Deposite amount into a particular account");
                 	 System.out.println("4. Withdraw amount");
                 	 System.out.println("5. Exit");
                 	 choice=sc.nextInt();
                 	 switch(choice)
                 	 {
                 	 	case 1:
                 	 		acc[cnt].accept();
                 	 		cnt++;
                 	 		break;
                 	 	case 2:
                 	 		for(int i=0;i<cnt;i++)
                 	 			acc[i].display();
                 	 		break;
                 	 	case 3:
                 	 		System.out.println("Enter account number: ");
                 	 		int a=sc.nextInt();
                 	 		System.out.println("Enter amount to be deposited: ");
                 	 		int amt=sc.nextInt();
                 	 		for(int i=0;i<acc.length;i++)
                 	 		{
                 	 			if(acc[i].getAccno()==a)
                 	 			{
                 	 				acc[i].deposite(amt);
                 	 			}
                 	 		}
                 	 		break;
                 	 	case 4:
                 	 		break;
                 	 	case 5:
                 	 		System.exit(0);
                 	 }
                 }
	}

}
