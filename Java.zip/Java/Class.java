import java.util.Scanner;
class Car
{
    private String name;
    private String color;
    private int price;

    // public Car(String n, String c, int p)
    // {
    //     this.name = n;
    //     this.color = c;
    //     this.price = p;
    // }

    public void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your car name: ");
        name = sc.next();
        System.out.println("Enter your color: ");
        color = sc.next();
        System.out.println("Enter your price: ");
        price = sc.nextInt();
    }

    public void display()
    {
        System.out.println("Your car name is: " + name);
        System.out.println("Your color name is: " + color);
        System.out.println("Your price is: " + price);
    }
}
public class Class {
    public static void main(String args[])
    {
        Car c = new Car();
        c.accept();
        c.display();
    }
    
}
