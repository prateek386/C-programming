class Employee
{
	private int empid;
	private String empname;
	private int salary; 
	
	
	public int getSalary()
	{
		return salary;
	}
	
	public Employee() 
	{
	       empid=101;
	       empname="abc";
	       salary=1000;
	}


public Employee(int id, String n, int s)
{
	empid=id;
	empname=n;
	salary=s;
}


public void display()
{
	System.out.println("Your EmpID is: " + empid);
	System.out.println("Your name is: " + empname);
	System.out.println("Your salary is: " + salary);
	System.out.println();
}

}
class Manager extends Employee
{
	private double petAllowance;
	private double foodAllowance;
	private double otherAllowance;
	public Manager()
	{
		 super();
	}
	
	public double calcpetAllowance()
	{		
		
		petAllowance = 0.08 * super.getSalary();
		return petAllowance;
	}
	
	public double calcfoodAllowance()
	{
		
		foodAllowance = 0.12 * super.getSalary();
		return foodAllowance;
	}
	
	public double calcotherAllowance()
	{
		
		otherAllowance = 0.04 * super.getSalary();
		return otherAllowance;
	}
	
	public double allowance()
	{
		double allows;
		allows=petAllowance + foodAllowance + otherAllowance;
		return allows;
	}
	
	public double PF()
	{
		double pf;
		pf = 0.125 * super.getSalary();
		return pf;
	}
	
	public double GrossSalary()
	{
		double gs;
		gs= super.getSalary() + petAllowance + foodAllowance + otherAllowance;;
		return gs;
	}
	
	public double NetSalary()
	{
		double ns;
		ns = GrossSalary() - PF();
		return ns;
	}
	
	public void display()
	{
		System.out.println("Your petrol allowance is: " + calcpetAllowance());
		System.out.println("Your food allowance is: " + calcfoodAllowance());
		System.out.println("The other allowance is: " + calcotherAllowance());
		System.out.println("Your GrossSalary allowance is: " + GrossSalary());
		System.out.println("Your Net Salary is: " + NetSalary());
		System.out.println();
	}
}	
	class MarketingExecutive extends Employee
	{
		private int km;
		private int tourAllowance;
		private int tel;
		public MarketingExecutive()
		{
			 super();
			 km=10;
			 tourAllowance=km*5;
			 tel=2000;
		}
				
		public double PF()
		{
			double pf;
			pf = 0.125 * super.getSalary();
			return pf;
		}
		
		public double GrossSalary()
		{
			double gs;
			gs = super.getSalary() + tourAllowance+tel;
			return gs;
		}
		
		public double NetSalary()
		{
			double ns;
			ns = GrossSalary() - PF();
			return ns;
		}
		public void display()
		{
		   System.out.println("Your GrossSalary is: " + GrossSalary());
		   System.out.println("Your Net Salary is: " + NetSalary());
		   System.out.println("Your PF is: "+PF());
		   System.out.println();
		}
	}
	
	public class Test
	{
		public static void main(String[] args)
		{
               Employee e = new Employee(10,"ben",8500);
               e.display();
               System.out.println();
                      
               Manager m= new Manager();
               m.display();
               System.out.println();
               
               MarketingExecutive me=new MarketingExecutive();
               m.display();
               System.out.println();
        
               
		}
	}





