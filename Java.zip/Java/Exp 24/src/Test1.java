
public class Test1 {

	public static void printObjects(Employee e) 
	{
	      e.display();	

	}
	public static void main(String[] args)
	{
	      MarketingExecutive me = new MarketingExecutive();
	      printObjects(me);
	      
	      Manager m=new Manager();
	      printObjects(m);
	      
	      Employee e=new Employee(10,"ben",8500);
	      printObjects(e);
	}
}
