import java.util.*;
public class Test {

		public static void main(String[] args)
		{
			Map<Integer, String> map=new TreeMap<>();
			map.put(101, "abc");
			map.put(11, "xyz");
			map.put(113, "pqr");
			map.put(15, "lmn");
			System.out.println(map);
		}

	}


