
public class OneD {

	public static void main(String[] args) {
		int []src= {6,7,8,9,10,23};
		int []dest=new int[6];
		System.arraycopy(src, 0, dest, 0, 6);
		for(int x:dest)
		{
			System.out.print(x+"  ");
		}
		System.out.println();
	}

}
