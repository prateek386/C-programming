package com.cdac.pack2;
import com.cdac.pack2.ClassBatch;
import static com.cdac.pack2.ClassBatch.showCnt;
import static java.lang.System.out;

class Test {

	public static void main(String[] args) {
		ClassBatch c1=new ClassBatch();
		c1.setCourseName("Computer");
		c1.setBatchStrength(5);
		System.out.println(c1);
		
		ClassBatch c2=new ClassBatch();
		c2.setCourseName("Data Structure");
		c2.setBatchStrength(6);
		System.out.println(c2);
		
		ClassBatch c3=new ClassBatch();
		c3.setCourseName("Microprocessor");
		c3.setBatchStrength(8);
		System.out.println(c3);
		
		
		showCnt();
		out.println("test print....");


	}

}
