package com.cdac.pack2;

 class ClassBatch {

	private String CourseName;
	private int BatchStrength;
	private static int cnt;
	public ClassBatch()
	{
		cnt++;
	}
	
	public ClassBatch(String CourseName, int BatchStrength)
	{
		this.CourseName=CourseName;
		this.BatchStrength=BatchStrength;
		cnt++;
	}
	
	public String getCourseName()
	{
		return CourseName;
	}
	
	public int getBatchStrength()
	{
		return BatchStrength;
	}
	
	public void setCourseName(String CourseName)
	{
		this.CourseName=CourseName;
	}
	
	public void setBatchStrength(int BatchStrength)
	{
		this.BatchStrength=BatchStrength;
	}
	
	
	
	@Override
	public String toString() {
		return "Student [CourseName=" + CourseName + ", BatchStrength=" + BatchStrength + "]";
	}
	public void display()
	{
		System.out.println(CourseName);
		System.out.println(BatchStrength);
	}
	
	
	public static void showCnt()
	{
		System.out.println(cnt);
	}
		

}
