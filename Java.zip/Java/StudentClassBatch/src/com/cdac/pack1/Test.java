package com.cdac.pack1;
import com.cdac.pack1.Student;
import static com.cdac.pack1.Student.showCnt;
import static java.lang.System.out;

public class Test {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.setRollno(10);
		s1.setName("Ben");
		System.out.println(s1);
		
		Student s2=new Student();
		s2.setRollno(20);
		s2.setName("Rex");
		System.out.println(s2);
		
		Student s3=new Student();
		s3.setRollno(30);
		s3.setName("Noah");
		System.out.println(s3);
		
		
		showCnt();
		out.println("test print....");

	}

}
