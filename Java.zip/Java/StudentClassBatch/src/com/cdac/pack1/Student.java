package com.cdac.pack1;

class Student {

	private int rollno;
	private String name;
	private static int cnt;
	public Student()
	{
		cnt++;
	}
	
	public Student(int rollno, String name)
	{
		this.rollno=rollno;
		this.name=name;
		cnt++;
	}
	public double getRollno()
	{
		return rollno;
	}
	public String getName()
	{
		return name;
	}
	
	
	public void setRollno(int rollno)
	{
		this.rollno=rollno;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	
	
	
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + "]";
	}
	public void display()
	{
		System.out.println(rollno);
		System.out.println(name);
	}
	
	
	public static void showCnt()
	{
		System.out.println(cnt);
	}
		

	}


