class Stack<G>
{
	private int size;
	private G [] arr;
	private int top;
	
	public Stack()
	{
		size=5;
		arr=(G[])new Object[size];
		top=-1;
	}
	
	public Stack(int s)
	{
		size=s;
		arr=(G[])new Object[size];
		top=-1;
	}
	
	public void push(G e)throws Exception
	{
		if(!isFull())
			arr[++top]=e;
		else
			throw new Exception("Overflow...");
	}
	
	public G pop() throws Exception
	{
		if(!isEmpty())
			return arr[top--];
		else
			throw new Exception("underflow...");
	}
	
	public boolean isFull()
	{
		return top==size-1;
	}
	
	public boolean isEmpty()
	{
		return top==-1;
	}
}
public class Test {
	public static void main(String[] args) {
		Stack<Integer> s1=new Stack<>();
		try
		{
			s1.push(12);
			s1.push(45);
			s1.push(23);
			s1.push(32);
			System.out.println(s1.pop());
			System.out.println(s1.pop());
			System.out.println(s1.pop());
			System.out.println(s1.pop());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		Stack<String> s2=new Stack<>();
		try
		{
			s2.push("tcs");
			s2.push("infosys");
			s2.push("persisitent");
			s2.push("wipro");
			System.out.println(s2.pop());
			System.out.println(s2.pop());
			System.out.println(s2.pop());
			System.out.println(s2.pop());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
