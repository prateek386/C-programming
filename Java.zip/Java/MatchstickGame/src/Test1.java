import java.util.Scanner;
public class Test1 {

	public static void main(String[] args) {
		int num, x, sum=0, mem;
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the number: ");
        num=sc.nextInt();
        mem=num;
        while(num>0)
        {
        	x=num%10;
        	num=num/10;
        	sum=sum+x*x*x;
        }
        if(sum==mem)
        {
            System.out.println("The number is armstrong");
	}
        else
        {
        	System.out.println("It is not an armstrong number");
        }
	}
}
