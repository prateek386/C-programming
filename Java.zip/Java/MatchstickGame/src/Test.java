import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int matchstick=21, pick;
		while(matchstick>1)
		{
			System.out.println("Pick matchstick between 1 to 4");
			pick=sc.nextInt();
			System.out.println("Computer picks "+(5-pick));
			matchstick=matchstick-5;
			System.out.println("Remaining mathcsticks: "+matchstick);
		}
		System.out.println("1 stick is remaining , you will loose the game");
	}

}
