import java.util.Scanner;
class Salaries
{
          public static void main(String[] args)
{
           float BS, SA, CS = 0 ;
           Scanner sc= new Scanner(System.in);
          System.out.println("Enter the BS : ");
            BS=sc.nextFloat();
             System.out.println("Enter the SA: ");
            SA=sc.nextFloat();

 if(SA<5000 && SA>7500)
{
        CS=BS * SA;
         System.out.println("commission percentage is: "+CS);
 }  
    else if(SA<7500 && SA>10500)
{
          CS=BS * SA;
         System.out.println("commission percentage is: "+CS);
}
     else if(SA<10500 && SA>15000)
 {     
                CS=BS * SA;
                System.out.println("commission percentage is: "+CS);
      }

float net_salary ;       
net_salary = BS + CS;
System.out.println("The net salary is: "+net_salary);
}
}
           
         
             
       
