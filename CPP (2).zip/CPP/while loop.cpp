#include<iostream>
using namespace std;
int main()
{
	int num;
	int i=1;
	while(i<=5)
	{
		cout<<i;
		i++;
	}
}
