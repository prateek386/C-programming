#include<iostream>
using namespace std;
int main()
{
	int intw;
	cin>>intw;
	
	int extw;
	cin>>extw;
	
	float sumi=0;
	
	for(int i=0; i<intw; i++)
	{
		float x;
		cin>>x;
		sumi+=x;
	}
	
	float pricei = sumi*18.0;
	
	float sume=0;
	
	for(int i=0; i<extw; i++)
	{
		float x;
		cin>>x;
		sume+=x;
	}
	
	float pricee = sume*12;
	
	float total = pricei + pricee;
	cout<<total;
	return 0;
}
