#include<iostream>
using namespace std;

//int power(int a, int b);
//
//
//int main()
//{
//	int a, b;
//	cin>>a>>b;
//	cout<<a<<"^"<<b<<" is: "<<power(a,b);
//}
//
//int power(int a, int b)
//{
//	int i, result=1;
//	for(i=1;i<=b;i++)
//	{
//		result = result*a;
//	}
//	return result;
//}

//int power(int a, int b)
//{
//	int i, result=1;
//	for(i=1; i<=b; i++)
//	{
//		result = result*a;
//	}
//	return result;
//}
//int main()
//{
//	int a, b;
//	cin>>a>>b;
//	cout<<a<<"^"<<b<<" is: "<<power(a,b);
//}

//Factorial number using function
int fact(int a)
{
	int fact=1;
	for(int i=1;i<=a; i++)
	{
		fact = fact*i;
	}
	return fact;
}

int main()
{
	int a;
	cin>>a;
	cout<<fact(a);
}
