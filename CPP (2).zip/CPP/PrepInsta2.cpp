//The oxygen value entered should not be accepted if it is not in the range
//between 1 and 100
//If the calculated maximum average oxygen value of trainee is below 70 then
//declare the trainee as unfit with meaningful message as "All trainees are unfit"
//Average oxygen values should be rounded
//Display the most fit trainee and highest average oxygen level

#include<iostream>
using namespace std;
int main()
{
    int trainee[3][3];
    int average[3] = {0};
    int max = 0;

    for(int i = 0; i<3; i++)
    {
        for(int j = 0;j<3;j++)
        {
            cin>>trainee[i][j];
            if(trainee[i][j]<1 || trainee[i][j]>100)
            {
                trainee[i][j] = 0;
            }
        }
    }

    for(int i=0; i<3; i++)
    {
        for(int j = 0;j<3;j++)
        {
            average[i] = average[i]+trainee[j][i];
        }
        average[i] = average[i]/3;
    }

    for(int i =0;i<3;i++)
    {
        if(average[i]>max)
        {
            max = average[i];
        }
    }

    for(int i = 0; i<3; i++)
    {
        if(average[i]==max)
        {
            cout<<"Trainee number: "<<i+1<<"\n";
        }
        if(average[i]<70)
        {
            cout<<"Invalid trainee";
        }
    }
    return 0;
}