#include<iostream>
using namespace std;

int fact(int a)
{
//	int fact = 1;
	if(a==0)
	return 1;
	else
	return a*fact(a-1); 
}

int main()
{
	int a;
	cin>>a;
	cout<<fact(a);	
}
