#include<iostream>
using namespace std;
int main()
{
//	int a[10];
//	for (int i=0; i<10; i++)
//	{
//		cin>>a[i];
//	}
//	
//	for (int i=0; i<10; i++)
//	{
//		cout<<a[i]<<" ";
//	}

//	int i=0;
//	while(i<3)
//	{
//		cout<<"Ben"<<endl;
//		i++;
//	}

//	int i=0;
//	do
//	{
//		cout<<"Ben"<<endl;
//		i++;
//	}
//	while(i<5);

int i, x=2;
for(i=0;i<3;i++)
{
	x*=2;
	cout<<x<<endl;
}
}
