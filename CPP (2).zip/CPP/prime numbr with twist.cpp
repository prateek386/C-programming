#include<iostream>
using namespace std;
void enter();
void check(int);
void prime(int);
int main()
{
	enter();
	return 0;
}
void enter()
{
	int num;
	cout<<"\n Enter the number: ";
	cin>>num;
	check(num);
}

void check(int num)
{
	if(num<0)
	{
		cout<<"\n Invalid number and enter it again: ";
		enter();
	}
	else
	{
		prime(num);
	}
}
void prime(int num)
{
	int i, div=0;
	for(int i = 1; i<=num; i++)
	{
		if(num%i == 0)
		{
			div++;
		}
	}
	
	if(div == 2)
	{
		cout<<num<<" is a prime number";
	}
	else
	{
		cout<<"It is not a prime number";
	}
}
