#include<iostream>
using namespace std;
int main()
{
	int num=0;
	int sum=0;
	cout<<"Enter a number: ";
	cin>>num;
	do
	{
		cout<<"Enter a number: ";
		cin>>num;
		sum+=num;
	}
	while(num>=0);
	cout<<"The sum is: "<<sum<<endl;
}
