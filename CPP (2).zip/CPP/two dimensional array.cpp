#include<iostream>
using namespace std;
int main()
{
	int num[2][3];
	cout<<"Enter 6 elements: "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			cin>>num[i][j];
		}
	}
	cout<<"Elements are: "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			cout<<"numbers["<<i<<"]["<<j<<"]: "<<num[i][j]<<endl;
		}
	}
}
