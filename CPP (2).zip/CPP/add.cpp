#include<iostream>
using namespace std;
int main()
{
    int a = 10;
    int b = 20;
    int c = a+b;
    cout<<"Adiition of two numbers is: "<<c;
    return 0;
    
}
