#include<iostream>
using namespace std;
int main(){
	float f;
	char a;
	f = 1.2;
	a = f;
	cout<< a <<endl;
}
