#include<iostream>
using namespace std;
int main()
{
	int n=10, k=5;
	int num;
	cout<<"Enter the number: ";
	cin>>num;
	
	if(num>=1 &&k<=5)
	{
		cout<<"No. of candies sold: "<<num<<endl;
		cout<<"No. of candies left: "<<n-num<<endl;
	}
	else
	{
		cout<<"Invalid candies"<<endl;
		cout<<"No. of candies left: "<<num<<endl;
	}
	
}
