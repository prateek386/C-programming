#include<iostream>
using namespace std;
int main()
//arithmetic operator
//{
//	int a= 14, b= 5, c;
//	cout<<a--<<" ";
//	cout<<a--<<" ";
//	cout<<a;
//}

// Logical operator
//{
//	int a=10, b=5;
//	cout<<(a==b) && (b == a);
//}
//{
//	int a= 10, b= 5;
//	cout<<!(a>b);
//}

//Bitwise Operator
{
	int a=10, b=5;
//	cout<<sizeof(a);
	cout<<b/a;
}
