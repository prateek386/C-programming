#include<iostream>
using namespace std;
void printPat(int n);
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		printPat(n);
		cout<<endl;
	}
}
