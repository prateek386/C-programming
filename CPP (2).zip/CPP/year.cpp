#include<iostream>
using namespace std;

int main()
{
	int year;
	cout<<"\n Enter a year number: ";
	cin>>year;
	
	if(year%4 == 0 && year%100 != 0 || year%400 == 0)
	{
		cout<<"\n This is a year";
	}
	else
	{
		cout<<"\n This is not a year";
	}
}
