#include<iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int c;
	cout<<"Enter the number: ";
	cin>>a>>b>>c;
	int d = a+b+c;
	cout<<"The sum is: "<< d <<endl;
}
