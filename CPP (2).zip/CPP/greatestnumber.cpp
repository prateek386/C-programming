#include<iostream>
using namespace std;
int main()
{
    int a;
    int b;
    cout<<"Enter the first number: ";
    cin>>a;
    cout<<"Enter the second number: ";
    cin>>b;
    if(a>b)
    {
        cout<<"The number "<<a<<" is greater";
    }
    else
    {
        cout<<"The number "<<b<<" is smaller";
    }
    return 0;
    

}