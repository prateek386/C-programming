//Given: N = 10 where N is number of candies available
//K <= 5 where k is number of minimum candidates taht must insider jar ever
//Condition: if N == 10 and K <=5 then display number of candies and number of candies left
//Else Invalid number and number of candies left

#include<iostream>
using namespace std;
int main()
{
    int n = 10;
    int k = 5;
    int num;
    
    cout<<"Enter your number: ";
    cin>>num;

    if(n==10 && k<=5)
    {
        cout<<"Number of candies is: "<<num;
        cout<<"\nNumber of candies available is: "<<n-num;
    }
    else
    {
        cout<<"Invalid Number";
        cout<<"Number of candies left: "<<n;
    }
    
}