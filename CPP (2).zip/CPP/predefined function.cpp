#include<iostream>
#include<cmath>
#include<cstring>
#include<cctype>
using namespace std;
int main()
{
//	pow()
//	int a=8, b=4;
//	cout<<pow(b, a);

// abs()
//	cout<<(7-6);

//sqrt()
//	cout<<sqrt(9);

//strlen()
//char a[] = "FACEprep";
//cout<<strlen(a);

//strcmp()
//char a[]="FACEprep", b[] = "FACEprep";
//cout<<strcmp(a,b);

//strncmp()
//char a[]="FACEprep", b[] = "FACEprep";
//cout<<strncmp(a,b,4);

//toupper()
//cout<<(char)toupper('a');
//cout<<toupper('a');

//cout<<(char)toupper('%');

//tolower()
//cout<<(char)tolower('Z');

//isupper()
cout<<isupper('f');
}
