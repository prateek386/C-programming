#include<iostream>
using namespace std;
int main()
{
	char str[16][10]={"goto","char","str","int","break","cont","strcmp","case"};
	char input[20];
	
	int flag = 0;
	cout<<"\n Enter the keyword: ";
	cin>>input;
	
	for(int i=0;i<=16;i++)
	{
		if(strcmp(input,str[i])==0)
		{
			flag = 1;
			break;
		}
	}
	if(flag == 1)
	{
		cout<< input <<" is a keyword ";
	}
	else
	{
		cout<< input <<" is not a keyword ";
	}
	return 0;
}
