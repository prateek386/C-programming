#include<iostream>
using namespace std;
int main()
{
    int year;
    cout<<"Enter the number for year: ";
    cin>>year;

    if((year==4) || (year!=100) && (year==400)){
        cout<<"This is a leap year";
    }
    else
    {
        cout<<"This is not a leap year";
    }
    return 0;
}