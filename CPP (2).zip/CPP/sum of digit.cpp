#include<iostream>
using namespace std;
int main()
{
	int n,sum;
	cout<<"Enter a number: ";
	cin>>n;
	for(int i=1;i<+n;i++)
	{
		sum+=i;
	}
	cout<<"The sum of "<<n<<" is: "<<sum;
}
