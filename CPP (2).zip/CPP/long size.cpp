#include<iostream>
using namespace std;
int main(){
	long a = 6.5543;
	int size = sizeof(a);
	cout<<size<<endl;
}
