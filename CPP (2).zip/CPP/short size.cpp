#include<iostream>
using namespace std;
int main(){
	short a = 8;
	int size = sizeof(a);
	cout<<size<<endl;
}
