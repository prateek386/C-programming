#include<iostream>
#include<cmath>
using namespace std;
int main()
{
//	int a = 8, b= 4;
//	cout<<pow(b,a);
//  cout<<abs(6-7);
//	cout<<sqrt(3);
}
