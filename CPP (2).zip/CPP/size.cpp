#include<iostream>
using namespace std;
int main()
{
	bool b = true;
	int size = sizeof(b);
	cout<< size <<endl;
}
