#include<iostream>
using namespace std;
int main(){
	int a;
	int b;
	int c = a+b;
	cout<<c<<endl;
}
