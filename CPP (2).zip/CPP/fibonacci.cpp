#include<iostream>
#include<math.h>
using namespace std;
double area_of_circle(double*radius)
{
	return M_PI*(*radius)*(*radius);
}
int main()
{
	double radius;
	cout<<"\nEnter the radius of a circle: ";
	cin>>radius;
	cout<<"\n Area of a circle: "<<area_of_circle(&radius);
	return 0;
}
