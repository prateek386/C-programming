#include<iostream>
using namespace std;
int main()
{
	 int a, b, c;
	 int max=0;
	 cout<<"\n Enter the three numbers: ";
	 cin>>a>>b>>c;
	 if(a>b && a>c)
	 cout<<"\n The largest number among three numbers is: "<<a;
	 else if(b>a && b>c)
	 cout<<"\n The largest number among three numbers is: "<<b;
	 else
	 cout<<"\n The largest number is: "<<c;
	 return 0;
}
