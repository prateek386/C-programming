#include<iostream>
using namespace std;
int main(){
	int i = 10;
	char c = 'a';
	
	int o = i + c;
	char d = i + c;
	cout<<o<<endl;
	cout<<d<<endl;
}
