#include<iostream>
using namespace std;
int gcd(int a, int b)
{
	if(b!=0)
	return gcd(b, a%b);
	else
	return a;
}
int main()
{
	int a, b;
	cout<"\n Enter the two numbers: ";
	cin>>a>>b;
	cout<<"\n GCD of "<<a<<" and "<<b<<" is: "<<gcd(a,b);
	return 0;
}
