#include<iostream>
using namespace std;
int main()
{
	int a, b, lcm;
	cout<<"\n Enter the two numbers: ";
	cin>>a>>b;
	lcm = (a>b)?a:b;
  	while(1)
  	{
  		if(lcm%a==0 && lcm%b==0)
  		{
  			cout<<"\n LCM of "<<a<<" and "<<b<<" is "<<lcm;
  			break;
		  }
		  ++lcm;
	  }
	  return 0;
}
