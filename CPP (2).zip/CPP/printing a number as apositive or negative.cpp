#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter an number: ";
	cin>>num;
	if(num>0)
	{
		cout<<"The number you entered is positive"<<endl;
	}
	else if(num<0)
	{
		cout<<"The number you have taken is negative"<<endl;
	}
	else
	{
		cout<<"The number you have taken is zero"<<endl;
	}
	cout<<"You have printed this number"<<endl;
}
